int T;
char c,s[1000];
main(){
	int i,j,k;
	while(~scanf("%d",&T)){
		while(T--){
			getchar();
			scanf("%c",&c);
			getchar();
			scanf("%s",s);
			for(i=j=0;s[i];i++) if(s[i]==c) j++;
			printf("%d\n",j);
		}
	}
}
