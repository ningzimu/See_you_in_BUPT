#include<queue>
#include<memory.h>
#include<cstdio>
using namespace std;
int T,n,m,e[101];
struct node{
	int lc,rc;
}t[101];
queue<int>Q,R;
main(){
	int i,j,k,l;
	scanf("%d",&T);
	for(k=1;k<=T;k++){
		scanf("%d%d",&n,&m);
		while(n--){
			scanf("%d%d",&i,&j);
			if(t[j].lc==0) t[j].lc=i;
			else t[j].rc=i;
			e[i]=j;
		}
		Q.push(1);
		Q.push(1);
		j=1;
		printf("Q%d:\n",k);
		while(!Q.empty()){
			i=Q.front();
			Q.pop();
			l=Q.front();
			Q.pop();
			if(t[i].lc){
				Q.push(t[i].lc);
				Q.push(l+1);
			}
			if(t[i].rc){
				Q.push(t[i].rc);
				Q.push(l+1);
			}
			if(j==l) R.push(i);
			else{
				j=l;
				printf("%d",R.front());
				R.pop();
				while(!R.empty()){
					printf(" %d",R.front());
					R.pop();
				}
				puts("");
				R.push(i);
			}
		}
		if(!R.empty()){
			printf("%d",R.front());
			R.pop();
			while(!R.empty()){
				printf(" %d",R.front());
				R.pop();
			}
			puts("");
		}
		memset(t,0,sizeof(t));
		memset(e,0,sizeof(e));
	}
}
